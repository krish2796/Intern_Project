/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mini;

/**
 *
 * @author HP
 */
public class report_from {
    public static void main(String[] args) {
    bill_form Formbill= new bill_form();
        Formbill.setVisible(true);
        Formbill.setLocationRelativeTo(null);
    }
    
}
