/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mini;

/**
 *
 * @author HP
 */
public class Attendance {
   
   private String AID;
   private int id;
   
   
}
