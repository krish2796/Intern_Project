/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tma3;

/**
 *
 * @author HP
 */
   public class Node {
    int data;
    Node left, right;
  
  
}
